#ifndef QUESTAO01_H_INCLUDED
#define QUESTAO01_H_INCLUDED

 void questao01(void);


#endif // QUESTAO01_H_INCLUDED
