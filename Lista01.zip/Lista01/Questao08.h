#ifndef QUESTAO08_H_INCLUDED
#define QUESTAO08_H_INCLUDED

void questao08(void);

#endif // QUESTAO08_H_INCLUDED
