#ifndef QUESTAO06_H_INCLUDED
#define QUESTAO06_H_INCLUDED

void questao06(void);

#endif // QUESTAO06_H_INCLUDED
