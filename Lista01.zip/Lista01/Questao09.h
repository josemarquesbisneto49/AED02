#ifndef QUESTAO09_H_INCLUDED
#define QUESTAO09_H_INCLUDED

void questao09(void);

#endif // QUESTAO09_H_INCLUDED
