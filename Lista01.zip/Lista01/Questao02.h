#ifndef QUESTAO02_H_INCLUDED
#define QUESTAO02_H_INCLUDED

void questao02(void);

#endif // QUESTAO02_H_INCLUDED
