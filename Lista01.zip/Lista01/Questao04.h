#ifndef QUESTAO04_H_INCLUDED
#define QUESTAO04_H_INCLUDED

void questao04(void);

#endif // QUESTAO04_H_INCLUDED
