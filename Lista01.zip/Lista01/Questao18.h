#ifndef QUESTAO18_H_INCLUDED
#define QUESTAO18_H_INCLUDED

void questao18(void);

#endif // QUESTAO18_H_INCLUDED
