#ifndef QUESTAO21_H_INCLUDED
#define QUESTAO21_H_INCLUDED

void questao21(void);

#endif // QUESTAO21_H_INCLUDED
