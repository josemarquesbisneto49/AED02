#ifndef QUESTAO16_H_INCLUDED
#define QUESTAO16_H_INCLUDED

void questao16(void);

#endif // QUESTAO16_H_INCLUDED
