#ifndef QUESTAO10_H_INCLUDED
#define QUESTAO10_H_INCLUDED

void questao10(void);

#endif // QUESTAO10_H_INCLUDED
