#ifndef QUESTAO23_H_INCLUDED
#define QUESTAO23_H_INCLUDED

void questao23(void);

#endif // QUESTAO23_H_INCLUDED
