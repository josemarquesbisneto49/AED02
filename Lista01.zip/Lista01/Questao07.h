
#ifndef QUESTAO07_H_INCLUDED
#define QUESTAO07_H_INCLUDED

void questao07 (void);

#endif // QUESTAO07_H_INCLUDED
