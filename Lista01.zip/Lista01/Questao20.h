#ifndef QUESTAO20_H_INCLUDED
#define QUESTAO20_H_INCLUDED

void questao20(void);

#endif // QUESTAO20_H_INCLUDED
