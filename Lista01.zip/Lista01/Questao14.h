#ifndef QUESTAO14_H_INCLUDED
#define QUESTAO14_H_INCLUDED

void questao14(void);

#endif // QUESTAO14_H_INCLUDED
