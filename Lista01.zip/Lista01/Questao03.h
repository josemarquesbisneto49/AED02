#ifndef QUESTAO03_H_INCLUDED
#define QUESTAO03_H_INCLUDED

void questao03 (void);

#endif // QUESTAO03_H_INCLUDED
