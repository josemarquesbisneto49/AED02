#ifndef QUESTAO15_H_INCLUDED
#define QUESTAO15_H_INCLUDED

void questao15(void);

#endif // QUESTAO15_H_INCLUDED
