#ifndef QUESTAO05_H_INCLUDED
#define QUESTAO05_H_INCLUDED

void questao05(void);

#endif // QUESTAO05_H_INCLUDED
