#ifndef QUESTAO11_H_INCLUDED
#define QUESTAO11_H_INCLUDED

void questao11(void);

#endif // QUESTAO11_H_INCLUDED
