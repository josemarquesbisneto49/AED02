#ifndef QUESTAO17_H_INCLUDED
#define QUESTAO17_H_INCLUDED

void questao17(void);

#endif // QUESTAO17_H_INCLUDED
