#ifndef QUESTAO13_H_INCLUDED
#define QUESTAO13_H_INCLUDED

void questao13(void);

#endif // QUESTAO13_H_INCLUDED
