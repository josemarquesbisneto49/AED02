#ifndef QUESTAO24_H_INCLUDED
#define QUESTAO24_H_INCLUDED

void questao24(void);

#endif // QUESTAO24_H_INCLUDED
