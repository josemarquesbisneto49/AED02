#ifndef QUESTAO12_H_INCLUDED
#define QUESTAO12_H_INCLUDED

void questao12(void);

#endif // QUESTAO12_H_INCLUDED
