#ifndef QUESTAO19_H_INCLUDED
#define QUESTAO19_H_INCLUDED

void questao19(void);

#endif // QUESTAO19_H_INCLUDED
