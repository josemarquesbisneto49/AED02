#ifndef QUESTAO22_H_INCLUDED
#define QUESTAO22_H_INCLUDED

void questao22(void);

#endif // QUESTAO22_H_INCLUDED
